from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

menu = {
    "Espresso": 80,
    "Americano": 90,
    "Cappuccino": 100,
    "Latte": 110,
    "Mocha": 120,
    "Ube Cheese Pandesal": 130,
    "Pande Asado": 199,
    "Cheese Roll": 199,
    "Choco Banana Cupcakes": 150,
    "Classic Cheesy Ensaymada": 199,
    "Cinnamon Roll": 249,
}

orders = []

@app.route("/")
def home():
    return render_template("menu.html", menu=menu)

@app.route("/order", methods=["POST"])
def order():
    item = request.form.get("item")
    qty = int(request.form.get("quantity", 1))
    if item in menu and qty > 0:
        subtotal = menu[item] * qty
        orders.append({"item": item, "qty": qty, "subtotal": subtotal})
    return redirect(url_for("receipt"))

@app.route("/receipt")
def receipt():
    total = sum(order["subtotal"] for order in orders)
    return render_template("receipt.html", orders=orders, total=total)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=81)
